import pygame
import random
import settings

# initializing window, sound, clock, sprites
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((settings.width, settings.height))
pygame.display.set_caption(settings.title)
clock = pygame.time.Clock()
all_sprites = pygame.sprite.Group()

# game loop
running = True
while running:

    # keep looping at the fps
    clock.tick(settings.fps)

    # process input
    for event in pygame.event.get():
        # closing window check
        if event.type == pygame.QUIT:
            running = False

    # UPDATE
    all_sprites.update()

    # RENDER
    screen.fill(settings.BLACK)
    all_sprites.draw(screen)
    # do this only after drawing everything
    pygame.display.flip()

